## Video

1. CouchPotatoServer  
CouchPotato is an automatic NZB and torrent downloader.  
Project Source: https://github.com/RuudBurger/CouchPotatoServer  
Project Homepage: https://couchpota.to/

1. coursera  
Script for downloading Coursera.org videos and naming them.  
Project Source: https://github.com/coursera-dl/coursera  

1. Medusa  
Medusa: Take full control of your PVR.  Select the results YOU want! Supports TVMaze, TMDB, and TVDB.  
Project Source: https://github.com/pymedusa/medusa

1. moviepy   
MoviePy is a Python module for script-based movie editing.  
Project Source: https://github.com/Zulko/moviepy  
Project Homepage: http://zulko.github.io/moviepy/

1. Sick-Beard  
PVR & episode guide that downloads and manages all your TV shows.  
Project Source: https://github.com/midgetspy/Sick-Beard  
Project Homepage: https://code.google.com/p/sickbeard/

1. SickGear  
SickGear, a usenet and bittorrent PVR  
Project Source: https://github.com/SickGear/SickGear

1. SickRage  
SickRage - Searches TheTVDB for shows.    
Project Source: https://github.com/SickRage/SickRage

1. SiCKRAGETV  
SickRage - Searches TheTVDB for shows.    
Project Source: https://github.com/SiCKRAGETV/SiCKRAGE

1. xunlei-lixian  
xunlei offline download script.  
Project Source: https://github.com/iambus/xunlei-lixian   

1. youtube-dl  
Download videos from youtube.com or other video platforms.  
Project Source: https://github.com/rg3/youtube-dl  
Project Homepage: http://rg3.github.io/youtube-dl/

1. you-get   
A YouTube/Youku/Niconico video downloader written in Python 3.   
Project Source: https://github.com/soimort/you-get   
Project Homepage: http://www.soimort.org/you-get/   
