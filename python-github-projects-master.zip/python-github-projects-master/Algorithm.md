## Algorithm

1. algorithms  
module of algorithms for Python.   
Project Source: https://github.com/nryoung/algorithms
 
2. pygorithm 
module for algorithms and data structures implemented purely in Python.
Project Source: https://github.com/OmkarPathak/pygorithm
