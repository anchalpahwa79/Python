## Static Web Generator

1. pelican  
Static site generator that supports Markdown and reST syntax.  
Project Source: https://github.com/getpelican/pelican  
Project Homepage: http://blog.getpelican.com/

1. cactus  
Cactus is a simple but powerful static website generator using Python and the Django template system.  
Project Source: https://github.com/koenbok/Cactus  
Online Demo Address: http://vimeo.com/46999791

1. hyde  
A Python Static Website Generator.  
Project Source: https://github.com/hyde/hyde.  
Project Homepage: http://hyde.github.io/ 

1. nikola   
A static website and blog generator.   
Project Source: https://github.com/getnikola/nikola   
Project Homepage: http://getnikola.com/  

1. mkdocs   
Project documentation with Markdown   
Project Source: https://github.com/tomchristie/mkdocs/    
Project Homepage: http://www.mkdocs.org/  
  
